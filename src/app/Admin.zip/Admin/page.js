"use client";
import '../../styles/globals.css'
import Admin from "./Admin";

export default function Home() {
  return (
    <Admin />
  );
}
