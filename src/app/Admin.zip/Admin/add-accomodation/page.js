
import AddAccomodation from "./AddAccomodation";

export default function Home() {
  return (
    <AddAccomodation />
  );
}
