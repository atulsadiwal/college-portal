
import AddCollege from "./AddCollege";

export default function Home() {
  return (
    <AddCollege />
  );
}
