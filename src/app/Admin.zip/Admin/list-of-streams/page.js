
import ListOfStreams from "./ListOfStreams";

export default function Home() {
  return (
    <ListOfStreams />
  );
}
