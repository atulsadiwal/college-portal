
import AddProgram from "./AddProgram";

export default function Home() {
  return (
    <AddProgram />
  );
}
