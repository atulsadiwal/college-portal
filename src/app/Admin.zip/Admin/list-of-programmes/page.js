
import ListOfProgrammes from "./ListOfProgrammes";

export default function Home() {
  return (
    <ListOfProgrammes />
  );
}
