
import AddAffiliation from "./AddAffiliation"

export default function Home() {
  return (
    <AddAffiliation />
  );
}
