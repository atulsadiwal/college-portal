
import React from 'react'

function EditDepartment() {
  return (
    <div>EditDepartment</div>
  )
}

export default EditDepartment