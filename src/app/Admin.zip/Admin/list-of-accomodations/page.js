
import ListOfAccomodations from "./ListOfAccomodations";

export default function Home() {
  return (
    <ListOfAccomodations />
  );
}
