export default function Admin() {
  return (
    <div>
      <h1 className="text-2xl font-bold">Welcome to the Admin Dashboard</h1>
      <p>Use the sidebar to navigate through different sections.</p>
    </div>
  );
}