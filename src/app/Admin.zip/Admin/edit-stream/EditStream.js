
import React from 'react'

function EditStream() {
  return (
    <div>EditStream</div>
  )
}

export default EditStream