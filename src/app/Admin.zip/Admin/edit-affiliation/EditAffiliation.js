
import React from 'react'

function EditAffiliation() {
  return (
    <div>EditAffiliation</div>
  )
}

export default EditAffiliation