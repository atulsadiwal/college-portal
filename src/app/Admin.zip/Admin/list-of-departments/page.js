
import ListOfDepartments from "./ListOfDepartments";

export default function Home() {
  return (
    <ListOfDepartments />
  );
}
