
import AddStream from "./AddStream";

export default function Home() {
  return (
    <AddStream />
  );
}
