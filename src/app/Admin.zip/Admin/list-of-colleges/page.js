
import ListOfColleges from "./ListOfColleges";

export default function Home() {
  return (
    <ListOfColleges />
  );
}
