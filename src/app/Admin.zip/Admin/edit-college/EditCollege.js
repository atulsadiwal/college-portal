
import React from 'react'

function EditCollege() {
  return (
    <div>EditCollege</div>
  )
}

export default EditCollege