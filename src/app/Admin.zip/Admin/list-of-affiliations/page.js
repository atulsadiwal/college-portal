
import ListOfAffiliations from "./ListOfAffiliations";

export default function Home() {
  return (
    <ListOfAffiliations />
  );
}
