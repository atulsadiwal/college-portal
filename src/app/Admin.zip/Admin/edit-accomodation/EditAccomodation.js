
import React from 'react'

function EditAccomodation() {
  return (
    <div>EditAccomodation</div>
  )
}

export default EditAccomodation