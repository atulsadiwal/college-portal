
import Mapping from "./Mapping";

export default function Home() {
  return (
    <Mapping />
  );
}
