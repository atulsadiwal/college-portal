
import AddDepartment from './AddDepartment';

export default function Home() {
  return (
    <AddDepartment />
  );
}
